drop table OPENJPA_SEQUENCE_TABLE;
drop table PEOPLE;
